(function() {
    var TerritoryFactory=function ($http, $rootScope) {
         console.log("At start of Territory Factory");   
        factory={};
       
        factory.getTerritoryData=function() {
            
              console.log("start of  getTerritoryData Factory");   
              return $http({
                  url: './data/Territory.json',
                  method: 'GET'
              }).then(
                 function (results) {
                     return results.data;
               });

           console.log("End of  getTerritoryData Factory");  
        };
         return factory;
         console.log("At end of Territory Factory");   
    };
     TerritoryFactory.$inject=['$http','$rootScope'];
      angular.module('northwindApp').factory('TerritoryFactory',TerritoryFactory);
    }());