(function() {
    var RegionFactory=function ($http, $rootScope) {
         console.log("At start of region Factory");   
        factory={};
       
        factory.getRegionData=function() {
            
              console.log("start of  getRegionData Factory");   
              return $http({
                  url: './data/Region.json',
                  method: 'GET'
              }).then(
                 function (results) {
                     return results.data;
               });

           console.log("End of  getRegionData Factory");  
        };
         return factory;
         console.log("At end of region Factory");   
    };
     RegionFactory.$inject=['$http','$rootScope'];
      angular.module('northwindApp').factory('RegionFactory',RegionFactory);
    }());