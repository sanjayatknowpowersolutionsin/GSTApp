(function() {
    var EmployeeAndTerritoryFactory=function ($http, $rootScope) {
        console.log("In EmployeeAndTerritoryFactory factory method");
        factory={};
       
        factory.getEmployeeTerritoryData=function() {
            
              console.log("start of  getEmployeeTerritoryData");   
              return $http({
                  url: './data/EmployeeandTerritory.json',
                  method: 'GET'
              }).then(
                 function (results) {
                     return results.data;
               });

           console.log("End of  getEmployeeTerritoryData");  
        }
        
        return factory;
         console.log("At end of EmployeeAndTerritoryFactory Factory");   
    };
       
  EmployeeAndTerritoryFactory.$inject=['$http','$rootScope'];
      angular.module('northwindApp').factory('EmployeeAndTerritoryFactory',EmployeeAndTerritoryFactory);
        
}());