(function() {
    var CategoryFactory=function ($http, $rootScope) {
        console.log("In Category factory method" );
        factory={};
       
        factory.getCategoryData=function() {            
              console.log("start of  getCategoryData Factory");   
              return $http({
                  url: './data/Categories.json',
                  method: 'GET'
              }).then(
                 function (results) {
                     return results.data;
               });
           console.log("End of  getCategoryData Factory");  
        }
        factory.getProductData = function () {
            console.log("start of getProductdata");
            return $http({
                url: './data/Products.json',
                method:'GET'
            }).then(
                function (results) {
                     return results.data;
            });
        }
        factory.SaveCategory=function(data,$scope) {
            console.log("start of  Save Category Factory");  
            console.log("End  of  AddCategory Factory");  
        }
        factory.getUpdateData=function(data,$scope) { 
			console.log("hiii..."+JSON.stringify(data));
             console.log("start of  getUpdateData Factory");   
             return $http({
                 url: './data/Categories.json',
                 method: 'PUT'
             }).then(
                 function (results) {
                     return results.data;
                 });
             console.log("End of  getUpdateData Factory");  
        
        }  
        factory.DeleteData=function(data,$scope) { 
             console.log("start of  DeleteData Factory");  
             return $http({
                 url: './data/Categories.json',
                 method: 'DELETE'
             }).then(
                function (results) {
                    return results.data;
                });
        
             console.log("End of  Delete Factory");  
        }           
            
        return factory;
         console.log("At end of Factory");   
    };
       
    CategoryFactory.$inject=['$http','$rootScope'];
    angular.module('northwindApp').factory('CategoryFactory',CategoryFactory);        
}());