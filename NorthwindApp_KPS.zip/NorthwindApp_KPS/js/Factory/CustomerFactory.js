(function() {
    var CustomerFactory=function ($http, $rootScope) {
        //console.log("In factory method");
        factory={};
       
        
        factory.getCustomerDataFromJson=function(data,$scope)
        {
              console.log("Customer Factory getCustomerDataFromJson");
                    return $http({                
                    url: './data/customerData.json',
                    method: 'GET'
                    }).then(
                        function(results){
                            console.log("Customer get data from JSON method results");
                            console.log(results);
                            return results.data;
                        });
             console.log(" end Customer Factory  getCustomerDataFromJson");
        }
        factory.saveCustomerData = function (data, $scope){
            var newData = JSON.stringify(data);
            console.log("hello",newData);
            
            console.log("In factory method in saveCustomerData"); 
            //var newData = JSON.stringify(data);
            //console.log("in factory - new Data", newData);
            return $http.post('./data/customerData.json', data).then(
            function (results) { 
                return results.data;
                console.log("In factory method results.data-->", results.data);
            });
        }
        /*factory.getCustomerData=function() {
            
              console.log("start of  getCustomerData Factory");   
              return $http({
                  url: './data/Customer.json',
                  method: 'GET'
              }).then(
                 function (results) {
                     return results.data;
               });

           console.log("End of  getCustomerData Factory");  
        }*/
       
        return factory;
         console.log("At end of Factory");   
    };
       
  CustomerFactory.$inject=['$http','$rootScope'];
      angular.module('northwindApp').factory('CustomerFactory',CustomerFactory);
        
}());