(function() {
    var ProductFactory=function ($http, $rootScope) {
        console.log("In ProductFactory method" );
        factory={};
      
        factory.getProductData = function () 
        {
            console.log("start of getProductdata");
            return $http({
                url: './data/Products.json',
                method:'GET'
            }).then(
                function (results) {
                     return results.data.Products;
            });
        }
        
            
        return factory;
         console.log("At end ProductFactory");   
    };
       
    ProductFactory.$inject=['$http','$rootScope'];
    angular.module('northwindApp').factory('ProductFactory',ProductFactory);        
}());