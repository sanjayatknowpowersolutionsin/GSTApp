(function() {
    var EmployeeFactory=function ($http, $rootScope) {
        console.log("In Employee factory method");
        factory={};
       
        factory.getEmployeeData=function() {
            
              console.log("start of  Employee Factory");   
              return $http({
                  url: './data/Employee.json',
                  method: 'GET'
              }).then(
                 function (results) {
                     return results.data;
               });

           console.log("End of  Employee Factory");  
        }
        
         factory.getSelectedEmployeeData=function() {
            
              console.log("start of  Employee Factory");   
              return $http({
                  url: './data/Employee.json',
                  method: 'GET'
              }).then(
                 function (results) {
                     return results.data;
               });

           console.log("End of  Employee Factory");  
        }
        
        return factory;
         console.log("At end of Factory");   
    };
       
  EmployeeFactory.$inject=['$http','$rootScope'];
      angular.module('northwindApp').factory('EmployeeFactory',EmployeeFactory);
        
}());