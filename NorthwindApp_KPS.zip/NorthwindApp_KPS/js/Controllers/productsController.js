(function () {

var productsController=function($scope,$http,$timeout,$location,$route,$routeParams){
        var data1=[];
        var data2=[];
    //console.log($scope.myname);
       $scope.Name="SEED";
        $scope.products=[];
        init();
        function init() {
            prodID = $routeParams.prodID;
            if (prodID != null && prodID != undefined && prodID != "")
            {   
                loadData(prodID);
            }
            else
            {
                loadData(null);
            }
        }
	    function loadData(prodID)
        { 
            if(prodID == null)
            {
                $http.get("./data/Products.json").then(function (response)
                {
                    console.log(JSON.stringify(response));
                    $scope.products = response.data.Products;
                    
                });
            } 
            else
            {                     
                $http.get("./data/Products.json").then(function (response)
                {
                    for(p=0;p< response.data.Products.length;p++)
                    {
                        var prdid=prodID.split(':')[1];
                        if(response.data.Products[p].SupplierID==prdid)
                        {
                            $scope.products.push(response.data.Products[p]); 
                        }
                            
                    }
                });
            }
        }    
        $scope.SelectProduct=function(vprodID)
        {
            console.log('selected product'+ vprodID);
            var newpath="/products:" + vprodID ;
            $location.path(newpath);
        }
    } 


    productsController.$inject=[ '$scope','$http', '$timeout','$location','$route','$routeParams'];
    
    /*Controller registration*/
    angular.module('northwindApp').controller('productsController',productsController);
   
}());
