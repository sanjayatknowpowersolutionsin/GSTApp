(function(){
       var nwCartController = function ($scope,ProductFactory) {
          $scope.invoice = {
        items: [{
            qty: 10,
            ProductName: 'item',
            UnitPrice: 9.95}]
    };
           $scope.selectedProduct ={};
            $scope.lstproducts =[];
           init();

           function init()
           {
                getproduct();
                console.log('Data in invoices');

           }

           function getproduct()
           {

               ProductFactory.getProductData().then(function (response)
             {
		          $scope.lstproducts = response;
                  console.log("List of products" + $scope.lstproducts);
             }, processError);


           }
           
           function processError()
           {};

    $scope.addItem = function() {
        console.log($scope.selectedProduct);

     for (var j = 0; j < $scope.lstproducts.length; j++)
                    {
            if($scope.lstproducts[j].ProductID ==$scope.selectedProduct.ProductID)
               { $scope.invoice.items.push(

                   {
            qty: 1,
            ProductName: $scope.lstproducts[j].ProductName,
            UnitPrice: parseFloat($scope.lstproducts[j].UnitPrice)}
                   );
               }}
    },

    $scope.removeItem = function(index) {
        $scope.invoice.items.splice(index, 1);
    },

    $scope.total = function() {
        var total = 0;
        angular.forEach($scope.invoice.items, function(item) {
            total += item.qty * item.UnitPrice;
        })

        return total;
    }
        console.log("At end of nwCartController ");
             //////////////////////////////////////////////////////////////////////////////////////////////
    $scope.merchantID ="bernardo.castilho-facilitator@gmail.com";
    $scope.checkoutPayPal = function (clearCart) {

    // global data
    var data = {
        cmd: "_cart",
        business:  $scope.merchantID,
        upload: "1",
        rm: "2",
        charset: "utf-8"
    };

    // item data
    for (var i = 0; i < $scope.invoice.items.length; i++) {
        var item = $scope.invoice.items[i];
        var ctr = i + 1;
        //data["item_number_" + ctr] = item.sku;
        data["item_name_" + ctr] = item.ProductName;
        data["quantity_" + ctr] = item.qty;
        data["amount_" + ctr] = item.UnitPrice;
    }

    // build form
    var form = $('<form/></form>');
    form.attr("action", "https://www.paypal.com/cgi-bin/webscr");
    form.attr("method", "POST");
    form.attr("style", "display:none;");
    $scope.addFormFields(form, data);
    //this.addFormFields(form, parms.options);
    $("body").append(form);

    // submit form
    this.clearCart = clearCart == null || clearCart;
    form.submit();
    form.remove();
}
    $scope.addFormFields = function (form, data) {
    if (data != null) {
        $.each(data, function (name, value) {
            if (value != null) {
                var input = $("<input></input>").attr("type", "hidden").attr("name", name).val(value);
                form.append(input);
            }
        });
    }
}

    
    
    
    };
    
  


    nwCartController.$inject=['$scope','ProductFactory'];

    /*Controller registration*/
    angular.module('northwindApp').controller('nwCartController',nwCartController);

 }());
