(function(){    
       var categoryController = function ($scope, $rootScope ,CategoryFactory,$location) {
        $scope.categoryData = [];
        $scope.categoryDetails = [];
        $scope.productData = [];
        $scope.productDetails = [];
        console.log("start of CategoryController" + $scope.categoryData);
        init();
        function init() {
            getCategoryName();
            getProductData();
        }
        $scope.changeCategory = function () 
        {
            $scope.productDetails = [];
			var i;
            console.log("In changeCategory selected category :- " + $scope.SelectedCategory);
            for (i = 0; i < $scope.categoryData.length; i++)
            {
                if ($scope.categoryData[i].CategoryID == $scope.SelectedCategory)
                {
                    $scope.categoryDetails = $scope.categoryData[i];
                    for (var j = 0; j < $scope.productData.Products.length; j++)
                    {
                        if($scope.productData.Products[j].CategoryID == $scope.SelectedCategory)
                        {
                            $scope.productDetails = $scope.productDetails.concat($scope.productData.Products[j]);     
                        }
                    }
                }
            }
        };
        $scope.SaveCategoryController = function () 
        { 
            console.log("Start of Save Controller"); 
		    CategoryFactory.getUpdateData($scope.categoryDetails).then(function (response) 
            {
		          $scope.categoryData = response;
                  console.log("Save Category Controller=" +response);
            }, processError);
        }
        function getCategoryName() {
            CategoryFactory.getCategoryData().then(function (response) {
                $scope.categoryData = response;
                console.log("getCategoryName Controller=" +response);
            }, processError);
        }
        function getProductData() {
            CategoryFactory.getProductData().then(function (response) {
                $scope.productData = response;
                console.log(response);
            }, processError);
        }
        $scope.getCategoryFactoryData = function () {
            console.log("start of Get controller");           
        };        
        function processError(error) {
            $scope.success = false;
            $scope.error = true;
            $scope.message = "";
            $scope.errormessage = error.data.message;
        }
        console.log("At end of Category Controller");
    };  
    categoryController.$inject=['$scope','$rootScope','CategoryFactory','$location'];
    
    /*Controller registration*/
    angular.module('northwindApp').controller('categoryController',categoryController);
 
 }());