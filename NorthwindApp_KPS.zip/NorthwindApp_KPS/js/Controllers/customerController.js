
(function () {
var customerController=function($scope,$http,$timeout,$location,CustomerFactory){           
        $scope.CustomerData = [];
        $scope.CustomerDetails = {};
        $scope.newCustomerData = [];
        function init()
        {
            $scope.getCustomerData();
        }        
        $scope.getCustomerData= function ()
        {
            console.log("In getCustomerData");
            CustomerFactory.getCustomerDataFromJson().then(function(response) 
            {
                $scope.CustomerData =response;
                console.log("$scope.CustomerData===", $scope.CustomerData);
            },processError);
        }
        init();         
        $scope.selectCustomer=function(selectCustID) {  
            console.log("selectCustID", selectCustID);
            for(c=0; c<$scope.CustomerData.length; c++){
                console.log("$scope.CustomerData[c]-->", $scope.CustomerData[c]);
                if($scope.CustomerData[c].customerId == selectCustID){
                    console.log("C and selectCustID is same");
                    $scope.CustomerDetails = $scope.CustomerData[c];                
                    console.log("CustomerDetails for edit -- >", $scope.CustomerDetails);
                }                
            }                   
        }        
        $scope.SaveCustomerDetails = function(){
            console.log("SaveCustomerDetails");            
            console.log("newCustomerData - >", $scope.CustomerDetails);
                        
            CustomerFactory.saveCustomerData($scope.CustomerDetails).then(function(response){
                 $scope.CustomerData = response;
                 console.log(response);
            });
        }        
        $scope.ResetCustomerDetails = function(){
            console.log("ResetCustomerDetails");
            $scope.CustomerDetails = {};
        }
        
        function processError(error)
        {
            console.log("In processError");
            $scope.success=false;
            $scope.error=true;
            $scope.message="";
            $scope.errormessage=error.data.Message;
        
        }        
    };
    customerController.$inject =['$scope','$http','$timeout','$location','CustomerFactory'];
    
     /*Controller registration*/
    angular.module('northwindApp').controller('customerController',customerController);
   
}());

