(function(){    
    var EmployeeController=function($scope,$rootScope,EmployeeFactory,RegionFactory,TerritoryFactory,EmployeeAndTerritoryFactory)
    {

        console.log("In EmployeeController");
        init();
        function init() 
        {
            getRegionName();
            getTerritoryData();
            getEmployeeTerritoryData();
            getEmployeeData();
        }
    
        $scope.employeeList=[];
        $scope.getEmployee= function ()
        {
            console.log("in getEmployee ");
            EmployeeFactory.getEmployeeData().then(function(response)
            {
                $scope.employeeList=response;
                console.log("Data in controller "+response) ;
            
            },processError);
            console.log("end getEmployee ");  
        };
    
        function processError(error)
        {
            console.log("in error ");
            $scope.success=false;
            $scope.error=true;
            $scope.message="";
            $scope.errormessage=error.data.message;
            console.log("end error ");
        }      
        $scope.regionData = [];
        $scope.regionDescription = [];
        $scope.territoryDetails=[];
        $scope.empterritoryDetails=[];
        $scope.empterritoryDesc=[];
        $scope.empData=[];
        $scope.employeeTWList=[];
        console.log("start of region" + $scope.regionData);
       
        $scope.changeRegion = function () 
        {       
            console.log("In changeRegion selected region :- " + $scope.SelectedRegion);
            for (var i = 0; i < $scope.regionData.length; i++)
            {
                if ($scope.regionData[i].RegionID == $scope.SelectedRegion)
                {
                    $scope.regionDescription = $scope.regionData[i];
                    console.log( $scope.regionData[i]);
                    for (var j = 0; j < $scope.territoryData.length; j++)
                    {
                        console.log( $scope.territoryData[j]);  
                        if($scope.territoryData[j].RegionID == $scope.SelectedRegion)
                        {   
                            $scope.territoryDetails.push($scope.territoryData[j]);                                           
                        }
                    }                  
                }                 
            }           
        };
        $scope.changeTerritory = function () 
        {
            console.log("In changeTerritory selected region :- " + $scope.SelectedTerritory); 
            for (var k = 0; k < $scope.empterritoryData.length; k++)
            { 
                if($scope.empterritoryData[k].TerritoryID == $scope.SelectedTerritory)
                {
                    $scope.empterritoryDesc=$scope.empterritoryData[k];
                    console.log($scope.empterritoryDesc);             
                    $scope.empterritoryDetails.push($scope.empterritoryData[k]);
                }   
            }
        };
        
        $scope.changeEmpTerritory= function ()
        {
            console.log("In changeEmpTerritory selected region :- " + $scope.SelectedEmpTerritory); 
            for (var k = 0; k < $scope.empData.length; k++)
            {
                if($scope.empData[k].EmployeeID == $scope.SelectedEmpTerritory)
                {
                    console.log($scope.empData[k]);
                    $scope.employeeTWList.push($scope.empData[k]);
                }
            }
            $scope.employeeList= $scope.employeeTWList[0];
        };
    
        function getRegionName() 
        {
            RegionFactory.getRegionData().then(function (response) {
                $scope.regionData = response;
                console.log(response);
            }, processError);
        }   
    
        function getTerritoryData() 
        {
            TerritoryFactory.getTerritoryData().then(function (response) {
            $scope.territoryData = response;
            console.log(response);
            }, processError);
        }  
    
        function getEmployeeTerritoryData() 
        {
            EmployeeAndTerritoryFactory.getEmployeeTerritoryData().then(function (response) {
            $scope.empterritoryData = response;
            console.log(response);
            }, processError);
        }
        
        function getEmployeeData() 
        {
            EmployeeFactory.getSelectedEmployeeData().then(function (response) {
            $scope.empData = response;
            console.log(response);
            }, processError);
        } 
    
        console.log("End EmployeeController");
    };     
    //inject the para to controller
    EmployeeController.$inject=             ['$scope','$rootScope','EmployeeFactory','RegionFactory','TerritoryFactory','EmployeeAndTerritoryFactory'];
    //register the controller
    angular.module('northwindApp').controller('EmployeeController',EmployeeController);    
}());