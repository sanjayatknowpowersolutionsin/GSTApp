(function () {
    'use strict';
    /*Controller registration*/
    angular.module('northwindApp').controller('ApiController', ApiController);
    ApiController.$inject = ['$scope'];

    function ApiController($scope) {

        /*angular.copy*/
        $scope.copyUser = {};
        $scope.saveUser = function (user) {
            angular.copy($scope.user, $scope.copyUser);
        }


        /*angular.equal*/
        $scope.user1 = {};
        $scope.user2 = {};
        $scope.result;
        $scope.compare = function () {
            $scope.result = angular.equals($scope.user1, $scope.user2);
        };
        
        /*angular.isDate*/
        $scope.res;
        $scope.ckeckDate = function(date){
        $scope.res = angular.isDate(Date);
        }
        
        /*angular.isNumber*/
        $scope.numResult;
        var number = parseInt($scope.number);
        $scope.ckeckNumber = function(){
            $scope.numResult = angular.isNumber(number);
        }
    $scope.invoice = {
        items: [{
            qty:0 , 
            description: 'item' ,
            cost:0 }]
    };

    $scope.addItem = function() {
        $scope.invoice.items.push({
            qty: 1,
            description: '',
            cost: 0
        });
    },

    $scope.removeItem = function(index) {
        $scope.invoice.items.splice(index, 1);
    },

    $scope.total = function() {
        var total = 0;
        angular.forEach($scope.invoice.items, function(item) {
            total += item.qty * item.cost;
        })

        return total;
    }
        
        /*angular.forEach*/
        
    $scope.invoice = {
        items: [{
            qty:0 , 
            description: 'item' ,
            cost:0 }]
    };

    $scope.addItem = function() {
        $scope.invoice.items.push({
            qty: 1,
            description: '',
            cost: 0
        });
    },

    $scope.removeItem = function(index) {
        $scope.invoice.items.splice(index, 1);
    },

    $scope.total = function() {
        var total = 0;
        angular.forEach($scope.invoice.items, function(item) {
            total += item.qty * item.cost;
        })

        return total;
    }
    
    /*angular.lowercase*/
        $scope.lowResult;
        $scope.lowerCase = function(){
            $scope.lowResult = angular.lowercase($scope.lowercase);
        }
        
        /*angular.uppercase*/
        $scope.upperResult;
        $scope.upperCase = function(){
            $scope.upperResult = angular.uppercase($scope.uppercase);
        }
    }
})();